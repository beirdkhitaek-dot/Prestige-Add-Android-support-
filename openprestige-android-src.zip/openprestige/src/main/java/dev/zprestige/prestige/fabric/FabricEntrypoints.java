package dev.zprestige.prestige.fabric;

import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.ui.mc.Entry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class FabricEntrypoints implements ModInitializer, ClientModInitializer {
    @Override
    public void onInitialize() {
        new Prestige().init();
    }

    @Override
    public void onInitializeClient() {
        Entry entry = new Entry();
        entry.initialize();
        ClientTickEvents.END_CLIENT_TICK.register(entry::tick);
    }
}
