package dev.zprestige.prestige.mixin;

import dev.zprestige.prestige.event.FireOverlayEvent;
import dev.zprestige.prestige.util.HookBridge;
import net.lenni0451.classtransform.InjectionCallback;
import net.lenni0451.classtransform.annotations.CTarget;
import net.lenni0451.classtransform.annotations.CTransformer;
import net.lenni0451.classtransform.annotations.injection.CInject;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;

@CTransformer({InGameOverlayRenderer.class})
public class InGameOverlayRendererMixin {
    @CInject(
        method = {"renderFireOverlay"},
        target = {@CTarget("HEAD")},
        cancellable = true
    )
    private static void hideFireOverlayAtHead(InjectionCallback ci) {
        FireOverlayEvent event = HookBridge.createFireOverlayEvent();
        if (HookBridge.postFireOverlayEvent(event)) {
            ci.cancel();
        }
    }
}
