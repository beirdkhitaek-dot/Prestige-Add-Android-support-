package dev.zprestige.prestige.render;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface RenderEvents {
    Logger LOGGER = LoggerFactory.getLogger(RenderEvents.class);
    RenderEvent HUD_RENDER = new RenderEvent();
    RenderEvent WORLD_RENDER = new RenderEvent();
    RenderEvent AFTER_HUD_RENDER = new RenderEvent();

    final class RenderEvent {
        private final CopyOnWriteArrayList<RenderCallback> listeners = new CopyOnWriteArrayList<>();
        private final RenderCallback invoker = (buffers, context) -> {
            for (RenderCallback listener : listeners) {
                try {
                    listener.onRender(buffers, context);
                } catch (Throwable throwable) {
                    LOGGER.error("Render listener failed", throwable);
                }
            }
        };

        public void register(RenderCallback listener) {
            listeners.add(Objects.requireNonNull(listener));
        }

        public RenderCallback invoker() {
            return invoker;
        }
    }
}
