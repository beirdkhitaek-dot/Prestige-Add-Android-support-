package dev.zprestige.prestige.ui.mc;

import dev.zprestige.prestige.ui.Input;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Opens the ported ClickGUI with the configured menu key (Input.menuKey, default RIGHT SHIFT); closing is handled by Input via the key mixin. */
public final class Entry {
    static boolean prev;
    private static int cachedVk = -1, cachedGlfw;

    public void initialize() {
        try { Skid.run(); } catch (Throwable t) { System.out.println("[prestige-ui] splash " + t); }
        System.out.println("[prestige-ui] loaded (menu key opens the menu)");
    }

    /** Menu key (Windows VK, as stored by Input) -> GLFW key, or -1 when unmapped. */
    static int menuGlfwKey() {
        int vk = Input.menuKey;
        if (vk != cachedVk) {
            cachedGlfw = -1;
            for (int g = 32; g <= 348 && cachedGlfw < 0; g++) if (Input.toVk(g) == vk) cachedGlfw = g;
            cachedVk = vk;
        }
        return cachedGlfw;
    }

    static boolean bridgeTried;

    public void tick(MinecraftClient mc) {
        if (dev.zprestige.prestige.client.Prestige.selfDestructed) return;
        if (!bridgeTried) { bridgeTried = true; dev.zprestige.prestige.ui.bridge.Bridge.bind(); }
        try {
            long h = mc.getWindow().getHandle();
            int key = menuGlfwKey();
            boolean down = key >= 0 && GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS;
            boolean justClosed = System.nanoTime() - Overlay.lastCloseNanos < 400_000_000L;
            if (down && !prev && !Overlay.visible && !justClosed) Overlay.open();
            prev = down;
            Overlay.tick(mc);
        } catch (Throwable t) {
            System.out.println("[prestige-ui] tick " + t);
        }
    }
}
