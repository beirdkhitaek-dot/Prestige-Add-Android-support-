package dev.zprestige.prestige.ui.mc;

import dev.zprestige.prestige.client.AppPaths;
import dev.zprestige.prestige.client.PlatformInfo;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.FileAlreadyExistsException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;

/** Selects the native binding by JVM architecture before ImGui initializes. */
final class ImGuiNative {
    private ImGuiNative() {}

    /**
     * Android's linker namespace only lets the JVM dlopen libraries from the app's private storage.
     * The game directory is usually on /storage/emulated/0 (not loadable), so use java.io.tmpdir,
     * which launchers point at the app's private cache. Override with -Dprestige.native.dir=...
     */
    private static Path nativeBase(boolean android) {
        String override = System.getProperty("prestige.native.dir");
        if (override != null && !override.isEmpty()) return Path.of(override);
        if (android) {
            String tmp = System.getProperty("java.io.tmpdir");
            if (tmp != null && !tmp.isEmpty()) return Path.of(tmp).resolve(".openprestige");
        }
        return AppPaths.runtime();
    }

    static void prepare() throws IOException {
        if (System.getProperty("imgui.library.path") != null) return;
        String arch = System.getProperty("os.arch").toLowerCase(Locale.ROOT);
        boolean arm = PlatformInfo.isArm64();
        String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        boolean android = PlatformInfo.isAndroid();
        String family = android ? "android" : os.startsWith("windows") ? "windows" : os.contains("mac") ? "macos" : "linux";
        String platform = family.equals("macos") ? "macos-universal" : family + (arm ? "-aarch64" : "-x86_64");
        String filename = System.mapLibraryName("imgui-java64");
        String resource = "/prestige-natives/" + platform + "/" + filename;
        InputStream opened = ImGuiNative.class.getResourceAsStream(resource);
        if (opened == null && android) {
            // Some Android launchers ship a glibc-compatible JVM; fall back to the Linux build.
            platform = "linux" + (arm ? "-aarch64" : "-x86_64");
            resource = "/prestige-natives/" + platform + "/" + filename;
            opened = ImGuiNative.class.getResourceAsStream(resource);
        }
        try (InputStream stream = opened) {
            if (stream == null) {
                if (android) throw new IOException("Missing Android ImGui binding " + resource + " (arch " + arch + ")");
                if (arm && !family.equals("macos")) throw new IOException("Missing ARM64 ImGui binding " + resource);
                return;
            }
            byte[] bytes = stream.readAllBytes();
            String digest;
            try {
                digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
            } catch (NoSuchAlgorithmException error) {
                throw new IOException("SHA-256 is unavailable", error);
            }
            Path directory = nativeBase(android).resolve("imgui").resolve(platform).resolve(digest);
            Files.createDirectories(directory);
            Path library = directory.resolve(filename);
            if (!Files.isRegularFile(library)) {
                Path temporary = Files.createTempFile(directory, "binding-", ".tmp");
                try {
                    Files.write(temporary, bytes);
                    try { Files.move(temporary, library); } catch (FileAlreadyExistsException ignored) {}
                } finally {
                    Files.deleteIfExists(temporary);
                }
            }
            System.setProperty("imgui.library.path", directory.toAbsolutePath().toString());
        }
    }
}
