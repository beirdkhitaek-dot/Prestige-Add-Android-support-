#!/bin/sh
# Build OpenPrestige for the current host. Optional JAVA_HOME selects the Gradle JDK.
set -eu
cd "$(dirname "$0")"
case "$(uname -s)" in
    Linux) LIB=libprestige_native.so ;;
    Darwin) LIB=libprestige_native.dylib ;;
    *) echo "Use build-injector.ps1 on Windows" >&2; exit 1 ;;
esac
if [ -n "${JAVA_HOME:-}" ]; then
    export JAVA_HOME
    PATH="$JAVA_HOME/bin:$PATH"
    export PATH
fi
./gradlew remapJar --console=plain
cargo build --release --manifest-path injector/Cargo.toml
mkdir -p dist
cp -f "injector/target/release/OpenPrestigeInjector" "injector/target/release/$LIB" dist/
chmod +x dist/OpenPrestigeInjector
for jar in build/libs/prestige-*.jar; do
    case "$jar" in *-dev.jar|*-sources.jar) continue ;; esac
    cp -f "$jar" dist/
done
echo "Done: dist/OpenPrestigeInjector + dist/$LIB + Fabric mod JAR"
