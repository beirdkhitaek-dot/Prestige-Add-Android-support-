@echo off
rem Builds fully offline OpenPrestige bundles.
rem   OpenPrestige CLI + native library with embedded payload
rem Requires Rust with MSVC x64/ARM64 tools, Python 3 and JDK 21.
rem Fetches pinned ImGui sources and cross-compiles the small JNI libraries.
setlocal EnableExtensions
cd /d "%~dp0"
set "SELF=%~f0"

set "OUT=%CD%\dist\release"
if exist "C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot" set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot"

for /f "tokens=1,* delims==" %%a in ('findstr /b /c:"mod_version=" gradle.properties') do set "VERSION=%%b"
if not defined VERSION set "VERSION=dev"
echo === Prestige %VERSION% release build

rem ---- tools -------------------------------------------------------------
where cargo >nul 2>&1 || (echo cargo not found: install Rust from https://rustup.rs & goto :fail)
where python >nul 2>&1 || (echo python not found: install Python 3 from https://python.org & goto :fail)
python -m ziglang version >nul 2>&1 || (
    echo === Installing zig ^(pip ziglang^)
    python -m pip install --user ziglang==0.16.0 || goto :fail
)
where cargo-zigbuild >nul 2>&1 || (
    echo === Installing cargo-zigbuild
    cargo install --locked cargo-zigbuild || goto :fail
)
rustup target add x86_64-pc-windows-msvc aarch64-pc-windows-msvc x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu x86_64-apple-darwin aarch64-apple-darwin || goto :fail

rem zigbuild's linker wrappers break on paths with spaces, so keep its cache on the 8.3 short path
if not exist "%LOCALAPPDATA%\cargo-zigbuild" mkdir "%LOCALAPPDATA%\cargo-zigbuild"
for %%I in ("%LOCALAPPDATA%\cargo-zigbuild") do set "CARGO_ZIGBUILD_CACHE_DIR=%%~sI"

rem ---- core ImGui JNI libraries ------------------------------------------
echo === Fetching sources and building small ImGui libraries
python scripts\build_release_imgui.py || goto :fail

rem ---- payload jar -------------------------------------------------------
echo === Building payload jar
call "%CD%\gradlew.bat" remapJar --console=plain || goto :fail
set "JAR="
for /f "delims=" %%j in ('dir /b /o-d "build\libs\prestige-*.jar" ^| findstr /v /i /c:"-dev.jar" /c:"-sources.jar"') do if not defined JAR set "JAR=%CD%\build\libs\%%j"
if not defined JAR (echo no remapped jar in build\libs & goto :fail)
rem The native library uses this exact payload JAR.
set "PRESTIGE_PAYLOAD=%JAR%"


if not exist "%OUT%" mkdir "%OUT%" || goto :fail

rem ---- native builds -----------------------------------------------------
call :build windows-x86_64 x86_64-pc-windows-msvc OpenPrestigeInjector.exe prestige_native.dll build || goto :fail
call :build windows-aarch64 aarch64-pc-windows-msvc OpenPrestigeInjector.exe prestige_native.dll build || goto :fail
call :build linux-x86_64 x86_64-unknown-linux-gnu OpenPrestigeInjector libprestige_native.so zigbuild x86_64-unknown-linux-gnu.2.17 || goto :fail
call :build linux-aarch64 aarch64-unknown-linux-gnu OpenPrestigeInjector libprestige_native.so zigbuild aarch64-unknown-linux-gnu.2.17 || goto :fail
call :build macos-universal universal2-apple-darwin OpenPrestigeInjector libprestige_native.dylib zigbuild || goto :fail

copy /y "%JAR%" "%OUT%\" >nul || goto :fail
python scripts\package_release.py checksums "%OUT%" || goto :fail
echo.
echo === Done: %OUT%
call :maybe_pause
exit /b 0

rem platform, target directory, executable, library, cargo command, optional versioned target
:build
set "BUILD_TARGET=%~2"
if not "%~6"=="" set "BUILD_TARGET=%~6"
echo === OpenPrestige %~1 (offline)
cargo %~5 --release --manifest-path injector\Cargo.toml --target "%BUILD_TARGET%" || exit /b 1
python scripts\package_release.py offline "%OUT%" "%VERSION%" %~1 "injector\target\%~2\release\%~3" "injector\target\%~2\release\%~4" "%JAR%"
exit /b %ERRORLEVEL%

:fail
echo.
echo *** Release build FAILED
call :maybe_pause
exit /b 1

rem keep the window open when started by double-click
:maybe_pause
echo %cmdcmdline% | find /i "%SELF%" >nul && pause
exit /b 0
