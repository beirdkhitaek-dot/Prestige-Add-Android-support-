# OpenPrestige offline injector

This repository contains the original CLI injector, native library with embedded payload and game
sources. The graphical launcher and runtime downloader are maintained in the separate Prestige
repository. There is no GUI or HTTP dependency in this injector and no edition build flag.

## Build

Run `build-injector.ps1` on Windows or `build-injector.sh` on Linux/macOS. Both build the Fabric JAR,
then the native library and CLI, collecting the results in `dist/`. The native library always embeds
the exact remapped JAR. The loose JAR is provided for optional installation as a Fabric mod.

Run `build-release.bat` on Windows to build all platforms. `dist/release/` contains:

```text
openprestige-<version>-windows-x86_64.zip
openprestige-<version>-windows-aarch64.zip
openprestige-<version>-linux-x86_64.zip
openprestige-<version>-linux-aarch64.zip
openprestige-<version>-macos-universal.zip
prestige-<version>.jar
SHA256SUMS.txt
```

Each ZIP contains `OpenPrestigeInjector` (or `.exe`), the native library, and a README.
The CI injector workflow builds only OpenPrestige. Build dependencies require internet access;
the resulting release bundle needs no runtime downloads.

## Use

Extract the complete platform ZIP, start Minecraft, then run:

```sh
OpenPrestigeInjector                  # Up/Down selects, Enter injects, Esc quits
OpenPrestigeInjector <pid> [lib path] # optional explicit library path
```

Keep the native library beside the executable. The CLI uses that library and never looks in
Prestige's downloaded runtime cache. It has no update checks or `--download` command.
The library writes its embedded JAR locally so the JVM can load it. No external JAR is needed for
injection. Linux/macOS require a terminal, the same user as the game, and JVM attach enabled.

## Platforms and requirements

Windows and Linux support x86_64 and ARM64. macOS supports Intel and Apple Silicon.
The injector, library and JVM architectures must match. ARM64 execution needs hardware testing.
The game code currently targets Minecraft 1.21.11 Fabric, Fabric Loader 0.19+ and Fabric API.

Build tools require Rust, Python 3 and JDK 21. On Windows, the full release build also requires
MSVC build tools for x64 and ARM64. `build-release.bat` fetches pinned ImGui sources and builds
the small JNI libraries before building the remapped JAR. It installs Zig and cargo-zigbuild if
needed, then cross-compiles Linux x64/ARM64 and universal macOS.

Both repositories currently start from the same game sources and use the compatible `.openprestige`
configuration and log locations. They are independent repositories, without submodules, shared
working files or edition build flags. Game code fixes must be ported between repositories explicitly.

## User data

| OS | Location |
| --- | --- |
| Windows | `%APPDATA%\.openprestige` |
| macOS | `~/Library/Application Support/.openprestige` |
| Linux | `$XDG_DATA_HOME/.openprestige` or `~/.local/share/.openprestige` |

Configs live in `configs/`, logs in `logs/`, and local runtime files in `runtime/`.
