//! Platform backends of the injector. Each backend exposes the same functions:
//! enable_ansi, poll_key, java_processes, inject, restore_terminal.

/// A running Minecraft JVM shown in the picker.
#[derive(PartialEq)]
pub struct JavaProcess {
    pub pid: u32,
    pub title: String,
    pub exe: String,
}

pub enum Key {
    Up,
    Down,
    Enter,
    Escape,
}

#[cfg(windows)]
mod win;
#[cfg(windows)]
pub use win::*;

#[cfg(unix)]
mod unix_attach;
#[cfg(unix)]
mod unix_procs;
#[cfg(unix)]
mod unix_term;
#[cfg(unix)]
pub use unix_attach::inject;
#[cfg(unix)]
pub use unix_procs::java_processes;
#[cfg(unix)]
pub use unix_term::{enable_ansi, poll_key, restore_terminal};

#[cfg(windows)]
pub const LIB_NAME: &str = "prestige_native.dll";
#[cfg(target_os = "macos")]
pub const LIB_NAME: &str = "libprestige_native.dylib";
#[cfg(all(unix, not(target_os = "macos")))]
pub const LIB_NAME: &str = "libprestige_native.so";
