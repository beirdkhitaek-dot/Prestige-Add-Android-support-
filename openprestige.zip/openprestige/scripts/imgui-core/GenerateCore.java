import com.badlogic.gdx.jnigen.NativeCodeGenerator;

public final class GenerateCore {
    public static void main(String[] args) throws Exception {
        new NativeCodeGenerator().generate(args[0], args[1], args[2], null,
                new String[] {"**/extension/**", "**/lwjgl3/**"});
    }
}
