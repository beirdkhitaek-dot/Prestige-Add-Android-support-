import imgui.ImDrawList;
import imgui.ImFontConfig;
import imgui.ImGui;
import imgui.ImGuiIO;
import imgui.type.ImInt;
import imgui.type.ImString;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Exercises core JNI entry points, real UI fonts, input widgets and draw data without a game. */
public final class SmokeTest {
    public static void main(String[] args) throws Exception {
        ImGui.createContext();
        try {
            ImGuiIO io = ImGui.getIO();
            io.setIniFilename(null);
            io.setDisplaySize(1000, 600);
            io.setDeltaTime(1.0f / 60);
            ImFontConfig config = new ImFontConfig();
            try {
                config.setPixelSnapH(true);
                io.getFonts().addFontFromMemoryTTF(Files.readAllBytes(Path.of(args[0])), 18, config);
            } finally {
                config.destroy();
            }
            if (!io.getFonts().build()) throw new AssertionError("Font atlas did not build");
            ImInt width = new ImInt();
            ImInt height = new ImInt();
            ByteBuffer pixels = io.getFonts().getTexDataAsRGBA32(width, height);
            if (pixels == null || width.get() <= 0 || height.get() <= 0) {
                throw new AssertionError("Font atlas is empty");
            }
            ImString input = new ImString("OpenPrestige", 64);
            float[] value = {0.5f};
            int vertices = 0;
            for (int frame = 0; frame < 3; frame++) {
                ImGui.newFrame();
                ImGui.setNextWindowSize(500, 350);
                ImGui.begin("Core JNI smoke test");
                ImGui.text("OpenPrestige core-only ImGui");
                ImGui.button("Inject");
                ImGui.sliderFloat("Scale", value, 0, 1);
                ImGui.inputText("Config name", input);
                ImDrawList draw = ImGui.getWindowDrawList();
                draw.addCircleFilled(100, 100, 20, 0xff80a0ff);
                draw.addText(120, 100, 0xffffffff, "Draw list");
                ImGui.end();
                ImGui.render();
                vertices = ImGui.getDrawData().getTotalVtxCount();
            }
            if (vertices <= 0) throw new AssertionError("No UI geometry was generated");
            System.out.println("Core JNI passed. Font atlas " + width.get() + "x" + height.get()
                    + ", vertices " + vertices);
        } finally {
            ImGui.destroyContext();
        }
    }
}
