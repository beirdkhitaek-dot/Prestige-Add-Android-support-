"""Package openprestige releases.

  package_release.py offline <out_dir> <version> <platform> <injector> <native_lib> <payload_jar>
  package_release.py checksums <out_dir>
"""
import hashlib
import os
import sys
import time
import zipfile

FOOTER = '\nCredits\n  Cracked by Skid Solutions\n  technix                       sourcing / Frida scripts\n  stutheguyy                    fixing\n  bynbang / nitrogenoliquido    ZKM transformers\n  dario                         AI models\n\nDiscord: https://discord.gg/x2FJyGrDNg\n'


def add(zf, arcname, data, mode):
    info = zipfile.ZipInfo(arcname, time.localtime()[:6])
    info.create_system = 3  # unix, so external_attr carries the permission bits
    info.external_attr = (0o100000 | mode) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    zf.writestr(info, data)


def make_zip(out_dir, version, platform, injector, lib, jar):
    if platform in ("windows-aarch64", "linux-aarch64"):
        native = "imgui-java64.dll" if platform.startswith("windows") else "libimgui-java64.so"
        with zipfile.ZipFile(jar) as payload:
            entry = f"prestige-natives/{platform}/{native}"
            if entry not in payload.namelist():
                raise ValueError(f"ARM64 payload is missing {entry}. Build the core ImGui natives first.")
    name = f"openprestige-{version}-{platform}"
    out = os.path.join(out_dir, name + ".zip")
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        executable = "OpenPrestigeInjector" + (".exe" if platform.startswith("windows-") else "")
        for path, filename, permissions in ((injector, executable, 0o755), (lib, os.path.basename(lib), 0o644)):
            with open(path, "rb") as file:
                add(bundle, f"{name}/{filename}", file.read(), permissions)
        readme = (f"OpenPrestige {version} - {platform}\n\n"
                  f"Extract this complete folder and run {executable}.\n"
                  "Original CLI: Up/Down selects a Minecraft JVM, Enter injects, Esc quits.\n"
                  f"Keep {os.path.basename(lib)} beside the executable.\n"
                  "The native library embeds its payload. No external JAR or runtime download is required.\n"
                  "The launcher has no downloader or update checks.\n\n"
                  "Requires a matching 64-bit Minecraft 1.21.11 Fabric JVM.\n"
                  "Linux/macOS: run from a terminal as the same user as the game; attach must be enabled.\n"
                  "The Fabric mod JAR is available separately. Use either injection or the mod.\n"
                  + FOOTER)
        add(bundle, f"{name}/README.txt", readme.encode(), 0o644)
    print(f"  wrote {out} ({os.path.getsize(out) // 1024} KiB)")


def checksums(out_dir):
    lines = []
    for entry in sorted(os.listdir(out_dir)):
        path = os.path.join(out_dir, entry)
        if not os.path.isfile(path) or entry == "SHA256SUMS.txt":
            continue
        with open(path, "rb") as f:
            lines.append(f"{hashlib.sha256(f.read()).hexdigest()}  {entry}\n")
    with open(os.path.join(out_dir, "SHA256SUMS.txt"), "w", newline="\n") as f:
        f.writelines(lines)


if __name__ == "__main__":
    if len(sys.argv) == 8 and sys.argv[1] == "offline":
        make_zip(*sys.argv[2:])
    elif len(sys.argv) == 3 and sys.argv[1] == "checksums":
        checksums(sys.argv[2])
    else:
        sys.exit(__doc__)
