"""Check this repository's release contents and architecture requirements."""
import contextlib
import hashlib
import io
from pathlib import Path
import tempfile
import unittest
import zipfile

import package_release


class ReleasePackaging(unittest.TestCase):
    def test_contents_and_checksums(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            injector = root / "injector.exe"
            library = root / "prestige_native.dll"
            jar = root / "prestige-1.2.3.jar"
            injector.write_bytes(b"launcher")
            library.write_bytes(b"library")
            with zipfile.ZipFile(jar, "w") as payload:
                payload.writestr("example.class", b"payload")
            out = root / "release"
            with contextlib.redirect_stdout(io.StringIO()):
                package_release.make_zip(str(out), "1.2.3", "windows-x86_64", str(injector), str(library), str(jar))
            archive = next(out.glob("*.zip"))
            with zipfile.ZipFile(archive) as bundle:
                names = {Path(name).name for name in bundle.namelist()}
                self.assertEqual(names, {"OpenPrestigeInjector.exe", library.name, "README.txt"})
                readme = bundle.read("openprestige-1.2.3-windows-x86_64/README.txt").decode()
                self.assertIn("embeds its payload", readme)
                self.assertNotIn("Keep the payload JAR beside", readme)
            package_release.checksums(str(out))
            expected = f"{hashlib.sha256(archive.read_bytes()).hexdigest()}  {archive.name}\n"
            self.assertEqual((out / "SHA256SUMS.txt").read_text(), expected)

    def test_arm_native_required(self):
        with tempfile.TemporaryDirectory() as directory:
            jar = Path(directory) / "prestige-1.2.3.jar"
            with zipfile.ZipFile(jar, "w"):
                pass
            with self.assertRaisesRegex(ValueError, "ARM64 payload is missing"):
                package_release.make_zip(directory, "1.2.3", "windows-aarch64", "unused.exe", "unused.dll", str(jar))


if __name__ == "__main__":
    unittest.main()
