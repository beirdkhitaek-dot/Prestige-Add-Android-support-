package dev.zprestige.prestige.client;

import java.nio.file.Path;

public final class AppPaths {
    private static final Path ROOT = root();

    private AppPaths() {}

    public static Path configs() {
        return ROOT.resolve("configs");
    }

    public static Path runtime() {
        return ROOT.resolve("runtime");
    }

    private static Path root() {
        String os = System.getProperty("os.name", "");
        Path base;
        if (os.startsWith("Windows")) {
            base = env("APPDATA");
            Path home = env("USERPROFILE");
            if (base == null && home != null) base = home.resolve("AppData").resolve("Roaming");
        } else {
            Path home = env("HOME");
            if (os.startsWith("Mac")) {
                base = home == null ? null : home.resolve("Library").resolve("Application Support");
            } else {
                base = env("XDG_DATA_HOME");
                if (base == null || !base.isAbsolute()) base = home == null ? null : home.resolve(".local").resolve("share");
            }
        }
        if (base == null) base = Path.of(System.getProperty("java.io.tmpdir"));
        return base.resolve(".openprestige");
    }

    private static Path env(String name) {
        String value = System.getenv(name);
        return value == null || value.isEmpty() ? null : Path.of(value);
    }
}
