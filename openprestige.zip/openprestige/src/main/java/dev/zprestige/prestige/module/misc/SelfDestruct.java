package dev.zprestige.prestige.module.misc;

import dev.zprestige.prestige.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.engine.EngineState;
import dev.zprestige.prestige.inject.Bootstrap;
import dev.zprestige.prestige.inject.NativeBridge;
import dev.zprestige.prestige.ui.mc.Overlay;
import java.util.ArrayList;
import java.util.List;

/**
 * Removes the client from the running game.
 *
 * Stage 1 (this tick): stop all client logic, close the menu, switch every other module off.
 * Stage 2 (next tick, after Module.toggle has returned): dispose the modules and empty the module list.
 * Stage 3 (injected clients only): put the original bytes back into every hooked game class and let the native loader unload.
 */
public class SelfDestruct extends Module {
    public SelfDestruct() {
        dev.zprestige.prestige.ui.bridge.Bootstrap.pre(this);
    }

    @Override
    public void onEnable() {
        if (Prestige.selfDestructed) return;
        Prestige.selfDestructed = true;
        System.out.println("[Prestige] Self Destruct started");
        Overlay.shutdown();

        List<Module> modules = new ArrayList<>(Prestige.moduleManager.getModules());
        for (Module module : modules) {
            if (module == this) {
                continue;
            }
            try {
                if (module.isEnabled()) {
                    module.toggle();
                }
            } catch (Throwable error) {
                error.printStackTrace();
            }
        }

        // Disposing this module now would null its own "Enabled" value while Module.toggle still has to read it.
        EngineState.ready = false;
        mc.send(() -> dispose(modules));
    }

    private void dispose(List<Module> modules) {
        Prestige.eventBus.unregister(this);
        Prestige.eventBus.unregister(Prestige.moduleManager);
        for (Module module : modules) {
            try {
                module.dispose();
                module.getKeybind().setValue(-1);
            } catch (Throwable error) {
                error.printStackTrace();
            }
        }
        Prestige.moduleManager.setModules(new ArrayList<>());

        if (Bootstrap.isInjected()) {
            unhook();
        } else {
            System.out.println("[Prestige] Self Destruct finished");
        }
    }

    private static void unhook() {
        try {
            if (Bootstrap.uninstall() == 0) {
                NativeBridge.release();
                System.out.println("[Prestige] Self Destruct finished");
            } else {
                System.out.println("[Prestige] Self Destruct left hooks installed. Restart the game to clear them.");
            }
        } catch (UnsatisfiedLinkError ignored) {
            // loader already gone
        } catch (Throwable error) {
            // an Error escaping a main-thread task would take the whole game down
            error.printStackTrace();
        }
    }

    @Override
    protected boolean requiresWorldOnEnable() {
        return false;
    }

    @Override
    public boolean isPersistent() {
        return false;
    }
}
